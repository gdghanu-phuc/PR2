package Tutorial_01;

public class Activity3 {
    public static void main(String[] args) {
        System.out.println("*****     *****");
        System.out.println("**   **   **");
        System.out.println("**    **  **");
        System.out.println("**    **  *****");
        System.out.println("**    **  **");
        System.out.println("**   **   **");
        System.out.println("*****     *****");
    }
}

